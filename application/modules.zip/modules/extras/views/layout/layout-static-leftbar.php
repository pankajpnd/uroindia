
<div class="static-content-wrapper">
    <div class="static-content">
        <div class="page-content">
            <ol class="breadcrumb">
                                
				<li><a href="index.html">Home</a></li>
				<li><a href="#">Layout</a></li>
				<li class="active"><a href="layout-static-leftbar.html">Static Leftbar</a></li>

            </ol>
            <div class="container-fluid">
                                 
				<div data-widget-group="group1">
					<div class="row">
						<div class="col-md-12">
							<div class="alert alert-info">
								<p>Static Leftbar (<strong>Default</strong>): static on large screen, scrolls on smaller screen</p>
							</div>
							<div class="panel panel-default" data-widget='{"draggable": "false"}'>
								<div class="panel-heading">
									<h2>Excepteur Sint</h2>
									<div class="panel-ctrls" data-actions-container="" data-action-collapse='{"target": ".panel-body"}'></div>
								</div>
								<div class="panel-body">
									<p class="m0">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>

            </div> <!-- .container-fluid -->
        </div> <!-- #page-content -->
    </div>
                