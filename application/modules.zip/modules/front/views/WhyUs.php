 <!-- About -->
        <div class="about-area pt-100 pb-70">
            <div class="container">
                
				<div class="row align-items-center">
                    <div class="col-lg-12">
                       
							<h2>Why Us</h2>
                            <p>Uroindia.com is one of the first and unique platform which is dedicated only for Urological consultation. People can get instant access to team of best and experienced Urologist all across the country to get the best opinion for their disease.</p>
							
							<p>This platform also unique because it has lot many things for Urologist as well.People from all across the country can ask their query and get answer. It saves time, money with the benefit of getting best possible advice from top doctors of the country just sitting at your home.</p>
							
                           <p>This is the ONLY platform in the country which is dedicated only for Urology.People can also get opinion about their sexual problem in which they usually hesitate to visit the clinic thereby prolonging their illness.</p>
							<p>Indian platform for Indian people.</p>
							
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- End About -->
