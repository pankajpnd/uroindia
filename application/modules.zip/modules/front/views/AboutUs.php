 <!-- About -->
        <div class="about-area pt-100 pb-70">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-item">
                            <div class="about-left">
                                <img src="<?php bs() ?>assets/img/home-one/4.jpg" alt="About">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-item about-right">
                            <img src="<?php bs() ?>assets/img/home-one/5.png" alt="About">
                            <h2>About Us</h2>
                            <p>Medical science and technology are growing day by day enormously. Every individual has the right of best treatment and best opinion by experts. But this is not possible without using digital platform without which people cannot get access to most of the experts around the country.</p>
							
							<p>Realising current need and working in field of Urology for more than 10 years Dr. Rajesh K Patel, Urologist and Kidney transplant surgeon, founder of UROINDIA.COM started this platform so that people all around the country can get access to best experts in the field of urology to get opinion. Dr. Rajesh K Patel is trained at one of the best institute in the country MULJIBHAI PATEL UROLOGICAL HOSPITAL, NADIAD, GUJARAT famous as Kidney hospital all around the world, for treating patients suffering from Urological and Kidney diseases.</p>
							
                           
                        </div>
                    </div>
                </div>
				<div class="row align-items-center">
                    <div class="col-lg-12">
                       
							<p>We have team of expert from all around the country to provide opinion. The team of doctors is verified and all are qualified Urologist and renowned doctors. Patient can post their queries and send reports to doctors to get second opinion. Anyone can consult top doctors from anywhere anytime and can save time and money. We have team of expert IT professionals and other supportive team whole work is taken care of by Co-founder Dr. Deepti Patel (Ophthalmologist).</p>
							
							<p>It also gives option to search nearby Urologist or any Urologist all around the country.This platform will also provide opportunity to put surgical videos, educational interview and search jobs and post jobs in addition to this there are many more things.</p>
							
							<p>This is unique platform which is useful to patients, doctors and other healthcare related persons.</p>
							
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- End About -->
