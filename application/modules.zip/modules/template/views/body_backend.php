<?php
$this->load->view('head_backend');
$this->load->view('sidebar_backend');
$this->load->view('header_backend');
$this->load->view($page);
$this->load->view('footer_backend');
?>
