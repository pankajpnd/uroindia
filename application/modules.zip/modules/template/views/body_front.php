<?php
$this->load->view('head_front');
$this->load->view('header_front');
$this->load->view($page);
$this->load->view('footer_front');
?>
